package wbcadventure;
import javax.swing.JFrame;
public class WBCAdventure {
    public static void main(String[] args) {
        BackgroundFrame bgFrame = new BackgroundFrame();
        
        bgFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bgFrame.setVisible(true);
    }
    
}
