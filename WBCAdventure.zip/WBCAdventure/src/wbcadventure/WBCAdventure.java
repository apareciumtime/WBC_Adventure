package wbcadventure;
import javax.swing.JFrame;
import java.util.ArrayList;
import javax.swing.ImageIcon;
public class WBCAdventure {
    public static void main(String[] args) {
        BackgroundFrame bgFrame = new BackgroundFrame();
        
        bgFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bgFrame.setVisible(true);
        
    }
    
}
