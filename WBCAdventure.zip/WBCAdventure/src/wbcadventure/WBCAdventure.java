package wbcadventure;
import javax.swing.*;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
public class WBCAdventure {
    public static void main(String[] args) {
        /*StartGame start = new StartGame();
        start.setBackground();
        start.setStartPoint();
        start.setUplayer();*/
        MainMenu menu = new MainMenu();
        menu.setBackground();
        menu.setButtons();
        
//        JFrame frame = new JFrame();
//        frame.setSize(1920,1080);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setVisible(true);
//        frame.setLayout(null);
//        
//        PathWay path = new PathWay(1);
//        JLabel label = new JLabel();
//        label.setIcon(path.getIcon(0));
//        label.setBounds(150, 15, 150, 150);
//        label.setOpaque(false);
//        frame.add(label);
        
    }
    
}