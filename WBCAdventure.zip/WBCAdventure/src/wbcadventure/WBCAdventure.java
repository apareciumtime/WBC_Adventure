package wbcadventure;
public class WBCAdventure {
    public static void main(String[] args) {
        
    }
    
}
