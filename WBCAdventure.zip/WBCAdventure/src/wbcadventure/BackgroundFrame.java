package wbcadventure;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.JProgressBar;
import java.io.InputStream;
import java.net.URL;
import javax.imageio.ImageIO;

public class BackgroundFrame extends JFrame{
    ImageIcon bg = new ImageIcon("src/source/background/background.jpg");   //background Image
    JLayeredPane layerPaneDefault = new JLayeredPane();                     //Default layer for background Image
    JLayeredPane layerPanePalette = new JLayeredPane();                     //Palette layer for path Image
    
    
    /**
     * BackgroundFrame default constructor use for start the first round game
     * User will start at the (0,0) point
     */
    public BackgroundFrame(){
        Dimension frameWork = new Dimension(1920,1080);
        this.setSize(frameWork);
        this.setLayout(null);
        this.setResizable(true);
        
        JLabel bgImg = new JLabel();
        bgImg.setIcon(bg);
        bgImg.setOpaque(true);
        bgImg.setBounds(0,0,1920,1080);
        
        ImageIcon pathImage = new ImageIcon("src/source/background/platePlain.png");
        JLabel path = new JLabel();
        path.setIcon(pathImage);
        path.setOpaque(false);
        path.setBounds(100,465,150,150);
        
        JLabel WBC = new JLabel();
        ImageIcon WBCIdle = new ImageIcon("src/source/character/WBC/WBCHappyForever.gif");
        WBC.setIcon(WBCIdle);
        this.add(WBC);
        WBC.setOpaque(false);
        WBC.setBounds(100,350,150,200);        
        
        layerPanePalette.add(WBC, JLayeredPane.PALETTE_LAYER);
        layerPanePalette.add(path, JLayeredPane.PALETTE_LAYER);
        layerPanePalette.setBounds(0,0,1920,1080);
        layerPanePalette.setVisible(true);
        
        layerPaneDefault.add(bgImg, JLayeredPane.DEFAULT_LAYER);
        layerPaneDefault.setBounds(0, 0, 1920, 1080);
        layerPaneDefault.setVisible(true);
        
        this.add(layerPanePalette);
        this.add(layerPaneDefault);  
        
          
        
        
    }
    
}
