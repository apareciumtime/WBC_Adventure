package wbcadventure;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import javax.swing.Icon;

public class BackgroundFrame extends JFrame{
    ImageIcon bg = new ImageIcon("src/source/background/background.png");   //background Image
    JLayeredPane layerPaneDefault = new JLayeredPane();                     //Default layer for background Image
    JLayeredPane layerPanePalette = new JLayeredPane();                     //Palette layer for path Image
    
    
    /**
     * BackgroundFrame default constructor use for start the first round game
     * User will start at the (0,0) point
     */
    public BackgroundFrame(){
        Dimension frameWork = new Dimension(1920,1080);
        this.setSize(frameWork);
        this.setLayout(null);
        this.setResizable(true);
        
        JLabel bgImg = new JLabel();
        bgImg.setIcon(bg);
        bgImg.setBounds(0,0,1920,1080);
        bgImg.setOpaque(true);
        
        bg.getImage();
        
        layerPaneDefault.add(bgImg, JLayeredPane.DEFAULT_LAYER);
        layerPaneDefault.setBounds(0, 0, 1920, 1080);
        layerPaneDefault.setVisible(true);
        
        
        this.add(layerPaneDefault);
        
        
    }
    
}
