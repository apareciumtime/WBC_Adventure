package wbcadventure;
public class Camera {
    
    public Camera(){
        
    }
    
}
